﻿namespace WPF.GettingStarted.Views
{
    public partial class PersonView
    {
        public PersonView()
        {
            InitializeComponent();
        }
    }
}
