﻿namespace WPF.GettingStarted.Views
{
    public partial class FamilyView
    {
        public FamilyView()
        {
            InitializeComponent();
        }
    }
}
