﻿namespace WPF.GettingStarted.Views
{
    using Catel.Windows;

    public partial class MainWindow
    {
        public MainWindow()
            : base(DataWindowMode.Custom)
        {
            InitializeComponent();
        }
    }
}
