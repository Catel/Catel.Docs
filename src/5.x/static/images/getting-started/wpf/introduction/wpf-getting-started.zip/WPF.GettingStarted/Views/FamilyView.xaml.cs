﻿namespace WPF.GettingStarted.Views
{
    using Catel.Windows.Controls;

    /// <summary>
    /// Interaction logic for FamilyView.xaml.
    /// </summary>
    public partial class FamilyView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FamilyView"/> class.
        /// </summary>
        public FamilyView()
        {
            InitializeComponent();
        }
    }
}
