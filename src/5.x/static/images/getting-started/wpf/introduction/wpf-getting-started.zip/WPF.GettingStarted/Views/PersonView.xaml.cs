﻿namespace WPF.GettingStarted.Views
{
    using Catel.Windows.Controls;

    /// <summary>
    /// Interaction logic for PersonView.xaml.
    /// </summary>
    public partial class PersonView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PersonView"/> class.
        /// </summary>
        public PersonView()
        {
            InitializeComponent();
        }
    }
}
